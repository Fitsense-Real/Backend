# Oraculo K20 · REV2_S_Mv21

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 1, "PASS": 29}
- Huella normalizada: `e0cc3474475dc9a3308651b6c93c21e59cfff32e1f69b20fc3503d8507d5704e`

| Usuario | Estado | Fallos |
|---|---|---|
| M01 | PASS | - |
| M02 | PASS | - |
| M03 | PASS | - |
| M04 | PASS | - |
| M05 | PASS | - |
| M06 | PASS | - |
| M07 | PASS | - |
| M08 | PASS | - |
| M09 | PASS | - |
| M10 | PASS | - |
| M11 | PASS | - |
| M12 | PASS | - |
| M13 | PASS | - |
| M14 | PASS | - |
| M15 | PASS | - |
| M16 | PASS | - |
| M17 | PASS | - |
| M18 | PASS | - |
| M19 | PASS | - |
| M20 | PASS | - |
| M21 | PASS | - |
| M22 | PASS | - |
| M23 | PASS | - |
| M24 | PASS | - |
| M25 | PASS | - |
| M26 | PASS | - |
| M27 | PASS | - |
| M28 | PASS | - |
| M29 | FAIL | A_generacion: 0 planes vigentes en S1 |
| M30 | PASS | - |
