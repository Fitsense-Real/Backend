# Oraculo K20 · REV2_Dp_L

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 1, "PASS": 15}
- Huella normalizada: `83bd199afbf7907a2178d397a96e55277df7a3b6a04477c4825e10f5b9d476a2`

| Usuario | Estado | Fallos |
|---|---|---|
| L01 | PASS | - |
| L02 | PASS | - |
| L03 | PASS | - |
| L04 | PASS | - |
| L05 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 5; F_publicacion: S2: 4 sesiones y el perfil pide 5; G_continuidad: S3: 4 sesiones y el perfil pide 5 |
| L06 | PASS | - |
| L07 | PASS | - |
| L08 | PASS | - |
| L09 | PASS | - |
| L10 | PASS | - |
| L11 | PASS | - |
| L12 | PASS | - |
| L13 | PASS | - |
| L14 | PASS | - |
| L15 | PASS | - |
| L16 | PASS | - |
