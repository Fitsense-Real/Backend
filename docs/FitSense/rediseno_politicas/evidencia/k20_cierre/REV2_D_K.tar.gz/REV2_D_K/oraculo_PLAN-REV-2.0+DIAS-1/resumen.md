# Oraculo K20 · REV2_D_K

- Configuracion de calculo activa: MVP-1.8
- Estados: {"PASS": 16}
- Huella normalizada: `73f28d978d322894c2a1f209660e4ac382d19f62c3721697c1c8858d90efe4c8`

| Usuario | Estado | Fallos |
|---|---|---|
| K01 | PASS | - |
| K02 | PASS | - |
| K03 | PASS | - |
| K04 | PASS | - |
| K05 | PASS | - |
| K06 | PASS | - |
| K07 | PASS | - |
| K08 | PASS | - |
| K09 | PASS | - |
| K10 | PASS | - |
| K11 | PASS | - |
| K12 | PASS | - |
| K13 | PASS | - |
| K14 | PASS | - |
| K15 | PASS | - |
| K16 | PASS | - |
