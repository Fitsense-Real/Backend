# Oraculo K20 · REV2_S_J

- Configuracion de calculo activa: MVP-1.8
- Estados: {"PASS": 16}
- Huella normalizada: `dafe6034a2c2142330ce3da52b71f1aed1831f161ab0b1f3d6c2c5dc8eab57c4`

| Usuario | Estado | Fallos |
|---|---|---|
| J01 | PASS | - |
| J02 | PASS | - |
| J03 | PASS | - |
| J04 | PASS | - |
| J05 | PASS | - |
| J06 | PASS | - |
| J07 | PASS | - |
| J08 | PASS | - |
| J09 | PASS | - |
| J10 | PASS | - |
| J11 | PASS | - |
| J12 | PASS | - |
| J13 | PASS | - |
| J14 | PASS | - |
| J15 | PASS | - |
| J16 | PASS | - |
