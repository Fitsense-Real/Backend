# Oraculo K20 · HIST_D_J

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 6, "PASS": 10}
- Huella normalizada: `276d535d6f96d34dbcd39c1b3f74c54fd0b028799784dba1b4165c00e4f09940`

| Usuario | Estado | Fallos |
|---|---|---|
| J01 | PASS | - |
| J02 | PASS | - |
| J03 | FAIL | A_generacion: 0 planes vigentes en S1 |
| J04 | PASS | - |
| J05 | FAIL | A_generacion: S1: V26O 27 series de chest en la semana > 24 / S1: V26O 27 series de upper legs en la semana > 24; F_publicacion: S2: V26O 27 series de chest en la semana > 24 / S2: V26O 27 series de upper legs en la semana > 24; G_continuidad: S3: V26O 27 series de chest en la semana > 24 / S3: V26O 27 series de upper legs en la semana > 24 |
| J06 | FAIL | A_generacion: S1 2026-11-03: V26O 11 series de upper legs en la sesion > 6 / S1 2026-11-06: V26O 11 series de upper legs en la sesion > 6 / S1: V26O 22 series de upper legs en la semana > 12; F_publicacion: S2 2026-11-10: V26O 11 series de upper legs en la sesion > 6 / S2 2026-11-13: V26O 11 series de upper legs en la sesion > 6 / S2: V26O 22 series de upper legs en la semana > 12; G_continuidad:  |
| J07 | PASS | - |
| J08 | PASS | - |
| J09 | FAIL | A_generacion: S1 2026-11-02: V26O 9 series de chest en la sesion > 6 / S1 2026-11-03: V26O 12 series de upper legs en la sesion > 6 / S1 2026-11-05: V26O 9 series de chest en la sesion > 6 / S1 2026-11-06: V26O 12 series de upper legs en la sesion > 6 / S1: V26O 18 series de chest en la semana > 12 / S1: V26O 24 series de upper legs en la semana > 12; F_publicacion: S2 2026-11-09: V26O 9 series de |
| J10 | PASS | - |
| J11 | PASS | - |
| J12 | FAIL | A_generacion: S1: V26O 17 series de chest en la semana > 12; F_publicacion: S2: V26O 17 series de chest en la semana > 12; G_continuidad: S3: V26O 17 series de chest en la semana > 12 |
| J13 | PASS | - |
| J14 | PASS | - |
| J15 | FAIL | A_generacion: S1: V26O 18 series de chest en la semana > 12; F_publicacion: S2: V26O 18 series de chest en la semana > 12; G_continuidad: S3: V26O 18 series de chest en la semana > 12 |
| J16 | PASS | - |
