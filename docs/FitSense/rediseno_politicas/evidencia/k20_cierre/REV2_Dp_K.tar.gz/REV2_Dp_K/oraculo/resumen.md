# Oraculo K20 · REV2_Dp_K

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 6, "PASS": 10}
- Huella normalizada: `73f28d978d322894c2a1f209660e4ac382d19f62c3721697c1c8858d90efe4c8`

| Usuario | Estado | Fallos |
|---|---|---|
| K01 | PASS | - |
| K02 | FAIL | A_generacion: S1 2026-11-02: V20 2226 s < 2814 s / S1 2026-11-04: V20 1896 s < 2814 s / S1 2026-11-06: V20 1896 s < 2814 s; F_publicacion: S2 2026-11-09: V20 2226 s < 2814 s / S2 2026-11-11: V20 1896 s < 2814 s / S2 2026-11-13: V20 1896 s < 2814 s; G_continuidad: S3 2026-11-16: V20 2226 s < 2814 s / S3 2026-11-18: V20 1896 s < 2814 s / S3 2026-11-20: V20 1896 s < 2814 s |
| K03 | PASS | - |
| K04 | PASS | - |
| K05 | FAIL | A_generacion: S1 2026-11-03: V20 1812 s < 1848 s / S1 2026-11-06: V20 1812 s < 1848 s; F_publicacion: S2 2026-11-10: V20 1812 s < 1848 s / S2 2026-11-13: V20 1812 s < 1848 s; G_continuidad: S3 2026-11-17: V20 1812 s < 1848 s / S3 2026-11-20: V20 1812 s < 1848 s |
| K06 | FAIL | A_generacion: S1 2026-11-04: V20 1134 s < 1386 s / S1 2026-11-06: V20 1134 s < 1386 s; F_publicacion: S2 2026-11-11: V20 1134 s < 1386 s / S2 2026-11-13: V20 1134 s < 1386 s; G_continuidad: S3 2026-11-18: V20 1134 s < 1386 s / S3 2026-11-20: V20 1134 s < 1386 s |
| K07 | PASS | - |
| K08 | PASS | - |
| K09 | FAIL | A_generacion: S1 2026-11-03: V20 1812 s < 2352 s / S1 2026-11-06: V20 1812 s < 2352 s; F_publicacion: S2 2026-11-10: V20 1812 s < 2352 s / S2 2026-11-13: V20 1812 s < 2352 s; G_continuidad: S3 2026-11-17: V20 1812 s < 2352 s / S3 2026-11-20: V20 1812 s < 2352 s |
| K10 | PASS | - |
| K11 | PASS | - |
| K12 | PASS | - |
| K13 | FAIL | A_generacion: S1 2026-11-02: V20 1860 s < 2814 s / S1 2026-11-03: V20 1584 s < 2814 s / S1 2026-11-05: V20 1980 s < 2814 s / S1 2026-11-06: V20 1464 s < 2814 s; F_publicacion: S2 2026-11-09: V20 1860 s < 2814 s / S2 2026-11-10: V20 1584 s < 2814 s / S2 2026-11-12: V20 1980 s < 2814 s / S2 2026-11-13: V20 1464 s < 2814 s; G_continuidad: S3 2026-11-16: V20 1860 s < 2814 s / S3 2026-11-17: V20 1584 s |
| K14 | FAIL | A_generacion: S1 2026-11-02: V20 2106 s < 2352 s / S1 2026-11-04: V20 1896 s < 2352 s / S1 2026-11-06: V20 1896 s < 2352 s; F_publicacion: S2 2026-11-09: V20 2106 s < 2352 s / S2 2026-11-11: V20 1896 s < 2352 s / S2 2026-11-13: V20 1896 s < 2352 s; G_continuidad: S3 2026-11-16: V20 2106 s < 2352 s / S3 2026-11-18: V20 1896 s < 2352 s / S3 2026-11-20: V20 1896 s < 2352 s |
| K15 | PASS | - |
| K16 | PASS | - |
