# Oraculo K20 · HIST_S_K

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 2, "PASS": 14}
- Huella normalizada: `afb572147323481bbf0d3e15393c4d42ba8113f1c312302a7b37b45e06cb5841`

| Usuario | Estado | Fallos |
|---|---|---|
| K01 | PASS | - |
| K02 | PASS | - |
| K03 | PASS | - |
| K04 | PASS | - |
| K05 | PASS | - |
| K06 | FAIL | A_generacion: S1: V26O 14 series de chest en la semana > 12; F_publicacion: S2: V26O 14 series de chest en la semana > 12; G_continuidad: S3: V26O 14 series de chest en la semana > 12 |
| K07 | PASS | - |
| K08 | PASS | - |
| K09 | PASS | - |
| K10 | PASS | - |
| K11 | PASS | - |
| K12 | PASS | - |
| K13 | FAIL | A_generacion: S1 2026-11-02: V26O 12 series de chest en la sesion > 6 / S1 2026-11-02: V26O 9 series de upper arms en la sesion > 6 / S1 2026-11-03: V26O 12 series de upper legs en la sesion > 6 / S1 2026-11-05: V26O 12 series de chest en la sesion > 6 / S1 2026-11-05: V26O 9 series de upper arms en la sesion > 6 / S1 2026-11-06: V26O 12 series de upper legs en la sesion > 6 / S1: V26O 24 series d |
| K14 | PASS | - |
| K15 | PASS | - |
| K16 | PASS | - |
