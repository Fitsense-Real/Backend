# Oraculo K20 · REV2_D_K

- Configuracion de calculo activa: MVP-1.8
- Estados: {"PASS": 16}
- Huella normalizada: `6f6256f5307cfb6ff3f4759d4cc93f7fc2b7a07b3cfac2402947797d41ee77cc`

| Usuario | Estado | Fallos |
|---|---|---|
| K01 | PASS | - |
| K02 | PASS | - |
| K03 | PASS | - |
| K04 | PASS | - |
| K05 | PASS | - |
| K06 | PASS | - |
| K07 | PASS | - |
| K08 | PASS | - |
| K09 | PASS | - |
| K10 | PASS | - |
| K11 | PASS | - |
| K12 | PASS | - |
| K13 | PASS | - |
| K14 | PASS | - |
| K15 | PASS | - |
| K16 | PASS | - |
