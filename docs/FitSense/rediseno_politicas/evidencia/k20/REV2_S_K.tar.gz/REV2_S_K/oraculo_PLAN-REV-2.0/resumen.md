# Oraculo K20 · REV2_S_K

- Configuracion de calculo activa: MVP-1.8
- Estados: {"PASS": 16}
- Huella normalizada: `7666ed3d9395b33d6cb63e3d8639a558cefaf37feabfb745fa237c2bd640667b`

| Usuario | Estado | Fallos |
|---|---|---|
| K01 | PASS | - |
| K02 | PASS | - |
| K03 | PASS | - |
| K04 | PASS | - |
| K05 | PASS | - |
| K06 | PASS | - |
| K07 | PASS | - |
| K08 | PASS | - |
| K09 | PASS | - |
| K10 | PASS | - |
| K11 | PASS | - |
| K12 | PASS | - |
| K13 | PASS | - |
| K14 | PASS | - |
| K15 | PASS | - |
| K16 | PASS | - |
