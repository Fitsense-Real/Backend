# Oraculo K20 · REV2_Dp_U

- Configuracion de calculo activa: MVP-1.8
- Estados: {"PASS": 20}
- Huella normalizada: `cdea34d7d2f75d0e0180ce4b1b2147e6a58c28c7334460757641c5e93ac3e48f`

| Usuario | Estado | Fallos |
|---|---|---|
| U01 | PASS | - |
| U02 | PASS | - |
| U03 | PASS | - |
| U04 | PASS | - |
| U05 | PASS | - |
| U06 | PASS | - |
| U07 | PASS | - |
| U08 | PASS | - |
| U09 | PASS | - |
| U10 | PASS | - |
| U11 | PASS | - |
| U12 | PASS | - |
| U13 | PASS | - |
| U14 | PASS | - |
| U15 | PASS | - |
| U16 | PASS | - |
| U17 | PASS | - |
| U18 | PASS | - |
| U19 | PASS | - |
| U20 | PASS | - |
