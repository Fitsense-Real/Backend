# Oraculo K20 · REV2_S_J

- Configuracion de calculo activa: MVP-1.8
- Estados: {"PASS": 16}
- Huella normalizada: `ef996d97480d141eb2291fda0d3e89100f436fdcac127ffb5aa9e15511cbc293`

| Usuario | Estado | Fallos |
|---|---|---|
| J01 | PASS | - |
| J02 | PASS | - |
| J03 | PASS | - |
| J04 | PASS | - |
| J05 | PASS | - |
| J06 | PASS | - |
| J07 | PASS | - |
| J08 | PASS | - |
| J09 | PASS | - |
| J10 | PASS | - |
| J11 | PASS | - |
| J12 | PASS | - |
| J13 | PASS | - |
| J14 | PASS | - |
| J15 | PASS | - |
| J16 | PASS | - |
