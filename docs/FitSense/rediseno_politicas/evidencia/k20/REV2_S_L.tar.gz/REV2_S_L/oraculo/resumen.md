# Oraculo K20 · REV2_S_L

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 7, "PASS": 9}
- Huella normalizada: `69672f33c13bad6f67cb34c1748739601cb2c15e63cad1cfcbb0e44b38bbed9d`

| Usuario | Estado | Fallos |
|---|---|---|
| L01 | FAIL | F_publicacion: S2 2026-11-12: V20 1518 s < 1764 s; G_continuidad: S3 2026-11-19: V20 1518 s < 1764 s |
| L02 | FAIL | A_generacion: S1 2026-11-02: V20 1572 s < 2226 s / S1 2026-11-04: V20 1134 s < 2226 s / S1 2026-11-06: V20 1134 s < 2226 s; F_publicacion: S2 2026-11-09: V20 1572 s < 2226 s / S2 2026-11-11: V20 1134 s < 2226 s / S2 2026-11-13: V20 1128 s < 2226 s; G_continuidad: S3 2026-11-16: V20 1572 s < 2226 s / S3 2026-11-18: V20 1134 s < 2226 s / S3 2026-11-20: V20 1128 s < 2226 s |
| L03 | PASS | - |
| L04 | PASS | - |
| L05 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 5; F_publicacion: S2: 4 sesiones y el perfil pide 5; G_continuidad: S3: 4 sesiones y el perfil pide 5 |
| L06 | PASS | - |
| L07 | PASS | - |
| L08 | FAIL | A_generacion: S1 2026-11-02: V20 2103 s < 2688 s / S1 2026-11-03: V20 1926 s < 2688 s / S1 2026-11-05: V20 2070 s < 2688 s / S1 2026-11-06: V20 1860 s < 2688 s; F_publicacion: S2 2026-11-09: V20 2103 s < 2688 s / S2 2026-11-10: V20 1926 s < 2688 s / S2 2026-11-12: V20 2070 s < 2688 s / S2 2026-11-13: V20 1854 s < 2688 s; G_continuidad: S3 2026-11-16: V20 2103 s < 2688 s / S3 2026-11-17: V20 1926 s |
| L09 | FAIL | A_generacion: S1 2026-11-02: V20 2640 s < 2688 s / S1 2026-11-03: V20 1812 s < 2688 s / S1 2026-11-05: V20 2640 s < 2688 s / S1 2026-11-06: V20 1812 s < 2688 s; F_publicacion: S2 2026-11-09: V20 2640 s < 2688 s / S2 2026-11-10: V20 1812 s < 2688 s / S2 2026-11-12: V20 2640 s < 2688 s / S2 2026-11-13: V20 1812 s < 2688 s; G_continuidad: S3 2026-11-16: V20 2640 s < 2688 s / S3 2026-11-17: V20 1812 s |
| L10 | PASS | - |
| L11 | PASS | - |
| L12 | PASS | - |
| L13 | FAIL | A_generacion: S1 2026-11-04: V20 2208 s < 2226 s; F_publicacion: S2 2026-11-11: V20 2208 s < 2226 s; G_continuidad: S3 2026-11-18: V20 2208 s < 2226 s |
| L14 | FAIL | A_generacion: S1 2026-11-02: V20 1134 s < 2688 s / S1 2026-11-03: V20 1152 s < 2688 s / S1 2026-11-05: V20 1134 s < 2688 s / S1 2026-11-06: V20 1152 s < 2688 s; F_publicacion: S2 2026-11-09: V20 1134 s < 2688 s / S2 2026-11-10: V20 1146 s < 2688 s / S2 2026-11-12: V20 1134 s < 2688 s / S2 2026-11-13: V20 1146 s < 2688 s; G_continuidad: S3 2026-11-16: V20 1134 s < 2688 s / S3 2026-11-17: V20 1146 s |
| L15 | PASS | - |
| L16 | PASS | - |
