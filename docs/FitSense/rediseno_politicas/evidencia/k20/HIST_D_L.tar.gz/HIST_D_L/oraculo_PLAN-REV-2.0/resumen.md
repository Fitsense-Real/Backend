# Oraculo K20 · HIST_D_L

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 8, "PASS": 8}
- Huella normalizada: `a137904895eced5babed8ffe2eb8c8f06727d423045b3b007c83e4ff7d0b943f`

| Usuario | Estado | Fallos |
|---|---|---|
| L01 | PASS | - |
| L02 | FAIL | A_generacion: S1 2026-11-02: V26O 8 series de chest en la sesion > 6 / S1 2026-11-02: V26O 8 series de upper legs en la sesion > 6 / S1 2026-11-04: V26O 7 series de chest en la sesion > 6 / S1 2026-11-06: V26O 7 series de chest en la sesion > 6 / S1: V26O 22 series de chest en la semana > 12 / S1: V26O 20 series de upper legs en la semana > 12; F_publicacion: S2 2026-11-09: V26O 8 series de chest  |
| L03 | PASS | - |
| L04 | FAIL | A_generacion: S1 2026-11-02: V4M 2055 s > 1860 s / S1 2026-11-04: V4M 2055 s > 1860 s / S1 2026-11-06: V4M 2013 s > 1860 s; F_publicacion: S2 2026-11-09: V4M 2055 s > 1860 s / S2 2026-11-11: V4M 2055 s > 1860 s / S2 2026-11-13: V4M 2013 s > 1860 s; G_continuidad: S3 2026-11-16: V4M 2055 s > 1860 s / S3 2026-11-18: V4M 2055 s > 1860 s / S3 2026-11-20: V4M 2013 s > 1860 s |
| L05 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 5; F_publicacion: S2: 4 sesiones y el perfil pide 5; G_continuidad: S3: 4 sesiones y el perfil pide 5 |
| L06 | PASS | - |
| L07 | PASS | - |
| L08 | FAIL | A_generacion: S1 2026-11-02: V26O 9 series de chest en la sesion > 6 / S1 2026-11-03: V26O 9 series de upper legs en la sesion > 6 / S1 2026-11-06: V26O 9 series de upper legs en la sesion > 6 / S1: V26O 15 series de chest en la semana > 12 / S1: V26O 18 series de upper legs en la semana > 12; F_publicacion: S2 2026-11-09: V26O 9 series de chest en la sesion > 6 / S2 2026-11-10: V26O 9 series de u |
| L09 | FAIL | A_generacion: S1 2026-11-03: V26O 12 series de upper legs en la sesion > 10 / S1 2026-11-06: V26O 12 series de upper legs en la sesion > 10; F_publicacion: S2 2026-11-10: V26O 12 series de upper legs en la sesion > 10 / S2 2026-11-13: V26O 12 series de upper legs en la sesion > 10; G_continuidad: S3 2026-11-17: V26O 12 series de upper legs en la sesion > 10 / S3 2026-11-20: V26O 12 series de upper |
| L10 | FAIL | A_generacion: S1 2026-11-02: V4M 1896 s > 1860 s / S1 2026-11-03: V4M 1896 s > 1860 s / S1 2026-11-05: V4M 1896 s > 1860 s; F_publicacion: S2 2026-11-09: V4M 1896 s > 1860 s / S2 2026-11-10: V4M 1896 s > 1860 s / S2 2026-11-12: V4M 1896 s > 1860 s; G_continuidad: S3 2026-11-16: V4M 1896 s > 1860 s / S3 2026-11-17: V4M 1896 s > 1860 s / S3 2026-11-19: V4M 1896 s > 1860 s |
| L11 | PASS | - |
| L12 | PASS | - |
| L13 | PASS | - |
| L14 | FAIL | A_generacion: S1 2026-11-02: V26O 10 series de chest en la sesion > 6 / S1 2026-11-03: V26O 10 series de upper legs en la sesion > 6 / S1 2026-11-05: V26O 10 series de chest en la sesion > 6 / S1 2026-11-06: V26O 10 series de upper legs en la sesion > 6 / S1: V26O 20 series de chest en la semana > 12 / S1: V26O 20 series de upper legs en la semana > 12; F_publicacion: S2 2026-11-09: V26O 10 series |
| L15 | FAIL | A_generacion: S1 2026-11-02: QINS 2 ejercicios y 6 series / S1 2026-11-03: V27O sesion PULL sin ejercicio de traccion / S1 2026-11-03: QINS 2 ejercicios y 6 series / S1 2026-11-04: QINS 2 ejercicios y 6 series / S1 2026-11-05: QINS 2 ejercicios y 6 series / S1 2026-11-06: QINS 2 ejercicios y 6 series; F_publicacion: S2 2026-11-09: QINS 2 ejercicios y 6 series / S2 2026-11-10: V27O sesion PULL sin  |
| L16 | PASS | - |
