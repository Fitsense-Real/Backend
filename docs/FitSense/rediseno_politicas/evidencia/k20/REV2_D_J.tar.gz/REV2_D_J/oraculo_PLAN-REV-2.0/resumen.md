# Oraculo K20 · REV2_D_J

- Configuracion de calculo activa: MVP-1.8
- Estados: {"PASS": 16}
- Huella normalizada: `7b1b94c64f699cafce3b99b8c6b2d117d2d4b8ec75baea8db01d09c260ea9257`

| Usuario | Estado | Fallos |
|---|---|---|
| J01 | PASS | - |
| J02 | PASS | - |
| J03 | PASS | - |
| J04 | PASS | - |
| J05 | PASS | - |
| J06 | PASS | - |
| J07 | PASS | - |
| J08 | PASS | - |
| J09 | PASS | - |
| J10 | PASS | - |
| J11 | PASS | - |
| J12 | PASS | - |
| J13 | PASS | - |
| J14 | PASS | - |
| J15 | PASS | - |
| J16 | PASS | - |
