# Oraculo K20 · R_U

- Configuracion de calculo activa: MVP-1.8
- Estados: {"PASS": 20}
- Huella normalizada: `6dc1b1312dade9c8c9e928a0952430ca32abfca1e691b22a21f292d197158341`

| Usuario | Estado | Fallos |
|---|---|---|
| U01 | PASS | - |
| U02 | PASS | - |
| U03 | PASS | - |
| U04 | PASS | - |
| U05 | PASS | - |
| U06 | PASS | - |
| U07 | PASS | - |
| U08 | PASS | - |
| U09 | PASS | - |
| U10 | PASS | - |
| U11 | PASS | - |
| U12 | PASS | - |
| U13 | PASS | - |
| U14 | PASS | - |
| U15 | PASS | - |
| U16 | PASS | - |
| U17 | PASS | - |
| U18 | PASS | - |
| U19 | PASS | - |
| U20 | PASS | - |
