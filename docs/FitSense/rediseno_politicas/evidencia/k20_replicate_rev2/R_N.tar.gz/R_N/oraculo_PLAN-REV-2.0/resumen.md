# Oraculo K20 · R_N

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 7, "PASS": 13}
- Huella normalizada: `6011231808184c0e119f89207c9d1bcec193942f0d4554970050f743fbaaea25`

| Usuario | Estado | Fallos |
|---|---|---|
| N01 | PASS | - |
| N02 | PASS | - |
| N03 | PASS | - |
| N04 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 6; F_publicacion: S2: 4 sesiones y el perfil pide 6; G_continuidad: S3: 4 sesiones y el perfil pide 6 |
| N05 | PASS | - |
| N06 | PASS | - |
| N07 | FAIL | A_generacion: S1: 6 sesiones y el perfil pide 7; F_publicacion: S2: 6 sesiones y el perfil pide 7; G_continuidad: S3: 6 sesiones y el perfil pide 7 |
| N08 | PASS | - |
| N09 | PASS | - |
| N10 | PASS | - |
| N11 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 6; F_publicacion: S2: 4 sesiones y el perfil pide 6; G_continuidad: S3: 4 sesiones y el perfil pide 6 |
| N12 | PASS | - |
| N13 | PASS | - |
| N14 | FAIL | A_generacion: S1: 6 sesiones y el perfil pide 7; F_publicacion: S2: 6 sesiones y el perfil pide 7; G_continuidad: S3: 6 sesiones y el perfil pide 7 |
| N15 | PASS | - |
| N16 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 5; F_publicacion: S2: 4 sesiones y el perfil pide 5; G_continuidad: S3: 4 sesiones y el perfil pide 5 |
| N17 | PASS | - |
| N18 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 6; F_publicacion: S2: 4 sesiones y el perfil pide 6; G_continuidad: S3: 4 sesiones y el perfil pide 6 |
| N19 | FAIL | A_generacion: 0 planes vigentes en S1 |
| N20 | PASS | - |
