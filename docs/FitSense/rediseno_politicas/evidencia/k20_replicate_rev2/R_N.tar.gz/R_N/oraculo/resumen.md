# Oraculo K20 · R_N

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 13, "PASS": 7}
- Huella normalizada: `6011231808184c0e119f89207c9d1bcec193942f0d4554970050f743fbaaea25`

| Usuario | Estado | Fallos |
|---|---|---|
| N01 | FAIL | F_publicacion: S2 2026-11-09: V20 1410 s < 1428 s; G_continuidad: S3 2026-11-16: V20 1410 s < 1428 s |
| N02 | FAIL | A_generacion: S1 2026-11-02: V20 1692 s < 2268 s / S1 2026-11-03: V20 1524 s < 2268 s / S1 2026-11-04: V20 1692 s < 2268 s / S1 2026-11-06: V20 1524 s < 2268 s / S1 2026-11-07: V20 1692 s < 2268 s; F_publicacion: S2 2026-11-09: V20 1692 s < 2268 s / S2 2026-11-10: V20 1524 s < 2268 s / S2 2026-11-11: V20 1692 s < 2268 s / S2 2026-11-13: V20 1524 s < 2268 s / S2 2026-11-14: V20 1692 s < 2268 s; G_c |
| N03 | PASS | - |
| N04 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 6 / S1 2026-11-04: V20 1926 s < 2058 s / S1 2026-11-08: V20 1860 s < 2058 s; F_publicacion: S2: 4 sesiones y el perfil pide 6 / S2 2026-11-11: V20 1926 s < 2058 s / S2 2026-11-12: V20 1726 s < 2058 s / S2 2026-11-15: V20 1860 s < 2058 s; G_continuidad: S3: 4 sesiones y el perfil pide 6 / S3 2026-11-18: V20 1926 s < 2058 s / S3 2026-11-19: V20 1726 s <  |
| N05 | PASS | - |
| N06 | FAIL | A_generacion: S1 2026-11-03: V20 1992 s < 2604 s; F_publicacion: S2 2026-11-10: V20 1968 s < 2604 s; G_continuidad: S3 2026-11-17: V20 1968 s < 2604 s |
| N07 | FAIL | A_generacion: S1: 6 sesiones y el perfil pide 7; F_publicacion: S2: 6 sesiones y el perfil pide 7; G_continuidad: S3: 6 sesiones y el perfil pide 7 |
| N08 | PASS | - |
| N09 | FAIL | A_generacion: S1 2026-11-03: V20 1812 s < 2058 s / S1 2026-11-05: V20 1860 s < 2058 s / S1 2026-11-06: V20 1692 s < 2058 s / S1 2026-11-08: V20 1980 s < 2058 s; F_publicacion: S2 2026-11-10: V20 1812 s < 2058 s / S2 2026-11-12: V20 1860 s < 2058 s / S2 2026-11-13: V20 1692 s < 2058 s / S2 2026-11-15: V20 1980 s < 2058 s; G_continuidad: S3 2026-11-17: V20 1812 s < 2058 s / S3 2026-11-19: V20 1860 s |
| N10 | FAIL | A_generacion: S1 2026-11-03: V20 2106 s < 2856 s / S1 2026-11-06: V20 1896 s < 2856 s / S1 2026-11-08: V20 1896 s < 2856 s; F_publicacion: S2 2026-11-10: V20 2106 s < 2856 s / S2 2026-11-13: V20 1896 s < 2856 s / S2 2026-11-15: V20 1896 s < 2856 s; G_continuidad: S3 2026-11-17: V20 2106 s < 2856 s / S3 2026-11-20: V20 1896 s < 2856 s / S3 2026-11-22: V20 1896 s < 2856 s |
| N11 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 6; F_publicacion: S2: 4 sesiones y el perfil pide 6; G_continuidad: S3: 4 sesiones y el perfil pide 6 |
| N12 | FAIL | F_publicacion: S2 2026-11-13: V20 2284 s < 2604 s; G_continuidad: S3 2026-11-20: V20 2284 s < 2604 s |
| N13 | PASS | - |
| N14 | FAIL | A_generacion: S1: 6 sesiones y el perfil pide 7 / S1 2026-11-02: V20 1692 s < 3024 s / S1 2026-11-03: V20 1524 s < 3024 s / S1 2026-11-04: V20 1692 s < 3024 s / S1 2026-11-06: V20 1524 s < 3024 s / S1 2026-11-07: V20 1692 s < 3024 s / S1 2026-11-08: V20 1524 s < 3024 s; F_publicacion: S2: 6 sesiones y el perfil pide 7 / S2 2026-11-09: V20 1692 s < 3024 s / S2 2026-11-10: V20 1524 s < 3024 s / S2 2 |
| N15 | PASS | - |
| N16 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 5 / S1 2026-11-02: V20 2136 s < 2856 s / S1 2026-11-04: V20 1926 s < 2856 s / S1 2026-11-06: V20 2070 s < 2856 s / S1 2026-11-08: V20 1860 s < 2856 s; F_publicacion: S2: 4 sesiones y el perfil pide 5 / S2 2026-11-09: V20 2136 s < 2856 s / S2 2026-11-11: V20 1926 s < 2856 s / S2 2026-11-13: V20 1764 s < 2856 s / S2 2026-11-15: V20 1860 s < 2856 s; G_con |
| N17 | PASS | - |
| N18 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 6 / S1 2026-11-02: V20 1362 s < 1428 s / S1 2026-11-04: V20 1152 s < 1428 s / S1 2026-11-06: V20 1152 s < 1428 s / S1 2026-11-07: V20 1152 s < 1428 s; F_publicacion: S2: 4 sesiones y el perfil pide 6 / S2 2026-11-09: V20 1362 s < 1428 s / S2 2026-11-11: V20 1152 s < 1428 s / S2 2026-11-13: V20 1152 s < 1428 s / S2 2026-11-14: V20 1152 s < 1428 s; G_con |
| N19 | FAIL | A_generacion: 0 planes vigentes en S1 |
| N20 | PASS | - |
