# Oraculo K20 · Rp_N

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 1, "PASS": 19}
- Huella normalizada: `6ca541fbf4816effc356a5c627b4484366d51d66672f98f6a959b6d4a7a80bd6`

| Usuario | Estado | Fallos |
|---|---|---|
| N01 | PASS | - |
| N02 | PASS | - |
| N03 | PASS | - |
| N04 | PASS | - |
| N05 | PASS | - |
| N06 | PASS | - |
| N07 | PASS | - |
| N08 | PASS | - |
| N09 | PASS | - |
| N10 | PASS | - |
| N11 | PASS | - |
| N12 | PASS | - |
| N13 | PASS | - |
| N14 | PASS | - |
| N15 | PASS | - |
| N16 | PASS | - |
| N17 | PASS | - |
| N18 | PASS | - |
| N19 | FAIL | A_generacion: 0 planes vigentes en S1 |
| N20 | PASS | - |
