# Oraculo K20 · REV2_D_J

- Configuracion de calculo activa: MVP-1.8
- Estados: {"PASS": 16}
- Huella normalizada: `97228f041355c23ee805da3782e343dc023c313a6263bf8a5056037e5ea256a8`

| Usuario | Estado | Fallos |
|---|---|---|
| J01 | PASS | - |
| J02 | PASS | - |
| J03 | PASS | - |
| J04 | PASS | - |
| J05 | PASS | - |
| J06 | PASS | - |
| J07 | PASS | - |
| J08 | PASS | - |
| J09 | PASS | - |
| J10 | PASS | - |
| J11 | PASS | - |
| J12 | PASS | - |
| J13 | PASS | - |
| J14 | PASS | - |
| J15 | PASS | - |
| J16 | PASS | - |
