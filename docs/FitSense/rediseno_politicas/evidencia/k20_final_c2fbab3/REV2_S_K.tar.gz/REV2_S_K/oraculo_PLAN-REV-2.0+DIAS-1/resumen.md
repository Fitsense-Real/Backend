# Oraculo K20 · REV2_S_K

- Configuracion de calculo activa: MVP-1.8
- Estados: {"PASS": 16}
- Huella normalizada: `8ad60c9bac83dedc40a0ab5fb2ae861c17f363e519c2f6f996e82bb07ab553be`

| Usuario | Estado | Fallos |
|---|---|---|
| K01 | PASS | - |
| K02 | PASS | - |
| K03 | PASS | - |
| K04 | PASS | - |
| K05 | PASS | - |
| K06 | PASS | - |
| K07 | PASS | - |
| K08 | PASS | - |
| K09 | PASS | - |
| K10 | PASS | - |
| K11 | PASS | - |
| K12 | PASS | - |
| K13 | PASS | - |
| K14 | PASS | - |
| K15 | PASS | - |
| K16 | PASS | - |
