# Oraculo K20 · HIST_D_M

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 8, "PASS": 22}
- Huella normalizada: `0e010d078d6a69b41d9537a952f8e2113b4601db96160b2e9c4afc692b2172a1`

| Usuario | Estado | Fallos |
|---|---|---|
| M01 | PASS | - |
| M02 | PASS | - |
| M03 | PASS | - |
| M04 | PASS | - |
| M05 | PASS | - |
| M06 | PASS | - |
| M07 | PASS | - |
| M08 | PASS | - |
| M09 | PASS | - |
| M10 | PASS | - |
| M11 | PASS | - |
| M12 | PASS | - |
| M13 | PASS | - |
| M14 | PASS | - |
| M15 | PASS | - |
| M16 | PASS | - |
| M17 | PASS | - |
| M18 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 5; F_publicacion: S2: 4 sesiones y el perfil pide 5; G_continuidad: S3: 4 sesiones y el perfil pide 5 |
| M19 | PASS | - |
| M20 | PASS | - |
| M21 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 6; F_publicacion: S2: 4 sesiones y el perfil pide 6; G_continuidad: S3: 4 sesiones y el perfil pide 6 |
| M22 | PASS | - |
| M23 | PASS | - |
| M24 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 6; F_publicacion: S2: 4 sesiones y el perfil pide 6; G_continuidad: S3: 4 sesiones y el perfil pide 6 |
| M25 | FAIL | A_generacion: S1: 6 sesiones y el perfil pide 7; F_publicacion: S2: 6 sesiones y el perfil pide 7; G_continuidad: S3: 6 sesiones y el perfil pide 7 |
| M26 | FAIL | A_generacion: S1: 6 sesiones y el perfil pide 7; F_publicacion: S2: 6 sesiones y el perfil pide 7; G_continuidad: S3: 6 sesiones y el perfil pide 7 |
| M27 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 7; F_publicacion: S2: 4 sesiones y el perfil pide 7; G_continuidad: S3: 4 sesiones y el perfil pide 7 |
| M28 | FAIL | A_generacion: S1: 6 sesiones y el perfil pide 7; F_publicacion: S2: 6 sesiones y el perfil pide 7; G_continuidad: S3: 6 sesiones y el perfil pide 7 |
| M29 | PASS | - |
| M30 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 7; F_publicacion: S2: 4 sesiones y el perfil pide 7; G_continuidad: S3: 4 sesiones y el perfil pide 7 |
