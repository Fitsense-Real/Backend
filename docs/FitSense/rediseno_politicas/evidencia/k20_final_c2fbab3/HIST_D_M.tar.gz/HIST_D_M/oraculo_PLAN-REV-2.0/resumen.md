# Oraculo K20 · HIST_D_M

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 18, "PASS": 12}
- Huella normalizada: `0e010d078d6a69b41d9537a952f8e2113b4601db96160b2e9c4afc692b2172a1`

| Usuario | Estado | Fallos |
|---|---|---|
| M01 | PASS | - |
| M02 | PASS | - |
| M03 | PASS | - |
| M04 | PASS | - |
| M05 | PASS | - |
| M06 | PASS | - |
| M07 | FAIL | A_generacion: S1 2026-11-03: QINS 2 ejercicios y 6 series / S1 2026-11-05: QINS 2 ejercicios y 6 series; F_publicacion: S2 2026-11-10: QINS 2 ejercicios y 6 series / S2 2026-11-12: QINS 2 ejercicios y 6 series; G_continuidad: S3 2026-11-17: QINS 2 ejercicios y 6 series / S3 2026-11-19: QINS 2 ejercicios y 6 series |
| M08 | PASS | - |
| M09 | PASS | - |
| M10 | PASS | - |
| M11 | PASS | - |
| M12 | FAIL | A_generacion: S1: V26O 15 series de back en la semana > 12 / S1: V26O 17 series de chest en la semana > 12; F_publicacion: S2: V26O 15 series de back en la semana > 12 / S2: V26O 17 series de chest en la semana > 12; G_continuidad: S3: V26O 15 series de back en la semana > 12 / S3: V26O 17 series de chest en la semana > 12 |
| M13 | FAIL | A_generacion: S1 2026-11-02: V26O 12 series de chest en la sesion > 10 / S1 2026-11-03: V26O 12 series de upper legs en la sesion > 10 / S1 2026-11-05: V26O 12 series de chest en la sesion > 10 / S1 2026-11-06: V26O 12 series de upper legs en la sesion > 10 / S1: V26O 24 series de chest en la semana > 20 / S1: V26O 24 series de upper legs en la semana > 20; F_publicacion: S2 2026-11-09: V26O 12 se |
| M14 | FAIL | A_generacion: S1 2026-11-03: V26O 12 series de upper legs en la sesion > 10 / S1 2026-11-06: V26O 12 series de upper legs en la sesion > 10; F_publicacion: S2 2026-11-10: V26O 12 series de upper legs en la sesion > 10 / S2 2026-11-13: V26O 12 series de upper legs en la sesion > 10; G_continuidad: S3 2026-11-17: V26O 12 series de upper legs en la sesion > 10 / S3 2026-11-20: V26O 12 series de upper |
| M15 | PASS | - |
| M16 | FAIL | A_generacion: S1 2026-11-02: V4M 1953 s > 1860 s / S1 2026-11-03: V4M 2055 s > 1860 s; F_publicacion: S2 2026-11-09: V4M 1953 s > 1860 s / S2 2026-11-10: V4M 2055 s > 1860 s; G_continuidad: S3 2026-11-16: V4M 1953 s > 1860 s / S3 2026-11-17: V4M 2055 s > 1860 s |
| M17 | FAIL | A_generacion: S1 2026-11-03: V26O 11 series de back en la sesion > 10; F_publicacion: S2 2026-11-10: V26O 11 series de back en la sesion > 10; G_continuidad: S3 2026-11-17: V26O 11 series de back en la sesion > 10 |
| M18 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 5; F_publicacion: S2: 4 sesiones y el perfil pide 5; G_continuidad: S3: 4 sesiones y el perfil pide 5 |
| M19 | PASS | - |
| M20 | FAIL | A_generacion: S1 2026-11-03: V26O 12 series de back en la sesion > 10 / S1 2026-11-04: V26O 11 series de upper legs en la sesion > 10; F_publicacion: S2 2026-11-10: V26O 12 series de back en la sesion > 10 / S2 2026-11-11: V26O 11 series de upper legs en la sesion > 10; G_continuidad: S3 2026-11-17: V26O 12 series de back en la sesion > 10 / S3 2026-11-18: V26O 11 series de upper legs en la sesion |
| M21 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 6 / S1 2026-11-04: V26O 9 series de upper legs en la sesion > 6 / S1 2026-11-07: V26O 9 series de upper legs en la sesion > 6 / S1: V26O 18 series de upper legs en la semana > 12; F_publicacion: S2: 4 sesiones y el perfil pide 6 / S2 2026-11-11: V26O 9 series de upper legs en la sesion > 6 / S2 2026-11-14: V26O 9 series de upper legs en la sesion > 6 / |
| M22 | FAIL | A_generacion: S1 2026-11-03: V26O 21 series de back en la sesion > 10 / S1 2026-11-04: V26O 21 series de upper legs en la sesion > 10 / S1 2026-11-06: V26O 21 series de back en la sesion > 10 / S1 2026-11-07: V26O 21 series de upper legs en la sesion > 10 / S1: V26O 42 series de back en la semana > 20 / S1: V26O 42 series de upper legs en la semana > 20; F_publicacion: S2 2026-11-10: V26O 21 serie |
| M23 | FAIL | A_generacion: S1 2026-11-03: V27O sesion PULL sin ejercicio de traccion / S1 2026-11-04: V26O 15 series de upper legs en la sesion > 10 / S1 2026-11-06: V27O sesion PULL sin ejercicio de traccion / S1 2026-11-07: V26O 15 series de upper legs en la sesion > 10 / S1: V26O 30 series de upper legs en la semana > 24; F_publicacion: S2 2026-11-10: V27O sesion PULL sin ejercicio de traccion / S2 2026-11- |
| M24 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 6; F_publicacion: S2: 4 sesiones y el perfil pide 6; G_continuidad: S3: 4 sesiones y el perfil pide 6 |
| M25 | FAIL | A_generacion: S1: 6 sesiones y el perfil pide 7 / S1 2026-11-03: V27O sesion PULL sin ejercicio de traccion / S1 2026-11-07: V27O sesion PULL sin ejercicio de traccion; F_publicacion: S2: 6 sesiones y el perfil pide 7 / S2 2026-11-10: V27O sesion PULL sin ejercicio de traccion / S2 2026-11-14: V27O sesion PULL sin ejercicio de traccion; G_continuidad: S3: 6 sesiones y el perfil pide 7 / S3 2026-11 |
| M26 | FAIL | A_generacion: S1: 6 sesiones y el perfil pide 7 / S1 2026-11-02: V4M 1896 s > 1860 s / S1 2026-11-03: V4M 1896 s > 1860 s / S1 2026-11-06: V4M 1896 s > 1860 s / S1 2026-11-07: V4M 1896 s > 1860 s; F_publicacion: S2: 6 sesiones y el perfil pide 7 / S2 2026-11-09: V4M 1896 s > 1860 s / S2 2026-11-10: V4M 1896 s > 1860 s / S2 2026-11-13: V4M 1896 s > 1860 s / S2 2026-11-14: V4M 1896 s > 1860 s; G_con |
| M27 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 7; F_publicacion: S2: 4 sesiones y el perfil pide 7; G_continuidad: S3: 4 sesiones y el perfil pide 7 |
| M28 | FAIL | A_generacion: S1: 6 sesiones y el perfil pide 7 / S1 2026-11-03: V27O sesion PULL sin ejercicio de traccion / S1 2026-11-07: V27O sesion PULL sin ejercicio de traccion; F_publicacion: S2: 6 sesiones y el perfil pide 7 / S2 2026-11-10: V27O sesion PULL sin ejercicio de traccion / S2 2026-11-14: V27O sesion PULL sin ejercicio de traccion; G_continuidad: S3: 6 sesiones y el perfil pide 7 / S3 2026-11 |
| M29 | FAIL | A_generacion: S1 2026-11-02: V4M 1896 s > 1800 s; F_publicacion: S2 2026-11-09: V4M 1896 s > 1800 s; G_continuidad: S3 2026-11-16: V4M 1896 s > 1800 s |
| M30 | FAIL | A_generacion: S1: 4 sesiones y el perfil pide 7 / S1 2026-11-04: V26O 9 series de upper legs en la sesion > 6 / S1 2026-11-07: V26O 9 series de upper legs en la sesion > 6 / S1: V26O 18 series de upper legs en la semana > 12; F_publicacion: S2: 4 sesiones y el perfil pide 7 / S2 2026-11-11: V26O 9 series de upper legs en la sesion > 6 / S2 2026-11-14: V26O 9 series de upper legs en la sesion > 6 / |
