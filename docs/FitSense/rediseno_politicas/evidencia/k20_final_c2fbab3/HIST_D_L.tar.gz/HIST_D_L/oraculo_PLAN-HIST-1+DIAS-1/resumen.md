# Oraculo K20 · HIST_D_L

- Configuracion de calculo activa: MVP-1.8
- Estados: {"PASS": 16}
- Huella normalizada: `a137904895eced5babed8ffe2eb8c8f06727d423045b3b007c83e4ff7d0b943f`

| Usuario | Estado | Fallos |
|---|---|---|
| L01 | PASS | - |
| L02 | PASS | - |
| L03 | PASS | - |
| L04 | PASS | - |
| L05 | PASS | - |
| L06 | PASS | - |
| L07 | PASS | - |
| L08 | PASS | - |
| L09 | PASS | - |
| L10 | PASS | - |
| L11 | PASS | - |
| L12 | PASS | - |
| L13 | PASS | - |
| L14 | PASS | - |
| L15 | PASS | - |
| L16 | PASS | - |
