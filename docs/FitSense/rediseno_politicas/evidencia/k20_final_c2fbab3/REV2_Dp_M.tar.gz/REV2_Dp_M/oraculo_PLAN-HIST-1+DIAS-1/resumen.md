# Oraculo K20 · REV2_Dp_M

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 15, "PASS": 15}
- Huella normalizada: `662e19cfd1eb47a88549e15ec1bbb572d55300b5a0b3fdd815c15590166dd5db`

| Usuario | Estado | Fallos |
|---|---|---|
| M01 | PASS | - |
| M02 | PASS | - |
| M03 | FAIL | A_generacion: S1 2026-11-02: V20 2508 s < 2772 s; F_publicacion: S2 2026-11-09: V20 2508 s < 2772 s; G_continuidad: S3 2026-11-16: V20 2508 s < 2772 s |
| M04 | FAIL | A_generacion: S1 2026-11-02: V20 3009 s < 3150 s; F_publicacion: S2 2026-11-09: V20 3009 s < 3150 s; G_continuidad: S3 2026-11-16: V20 3009 s < 3150 s |
| M05 | FAIL | A_generacion: S1 2026-11-03: V20 3108 s < 3150 s / S1 2026-11-05: V20 2988 s < 3150 s; F_publicacion: S2 2026-11-10: V20 3108 s < 3150 s / S2 2026-11-12: V20 2988 s < 3150 s; G_continuidad: S3 2026-11-17: V20 3108 s < 3150 s / S3 2026-11-19: V20 2988 s < 3150 s |
| M06 | FAIL | A_generacion: S1 2026-11-05: V20 1134 s < 1260 s; F_publicacion: S2 2026-11-12: V20 1134 s < 1260 s; G_continuidad: S3 2026-11-19: V20 1134 s < 1260 s |
| M07 | PASS | - |
| M08 | PASS | - |
| M09 | FAIL | A_generacion: S1 2026-11-04: V20 1428 s < 1596 s; F_publicacion: S2 2026-11-11: V20 1428 s < 1596 s; G_continuidad: S3 2026-11-18: V20 1428 s < 1596 s |
| M10 | FAIL | A_generacion: S1 2026-11-04: V20 1896 s < 1932 s / S1 2026-11-06: V20 1896 s < 1932 s; F_publicacion: S2 2026-11-11: V20 1896 s < 1932 s / S2 2026-11-13: V20 1896 s < 1932 s; G_continuidad: S3 2026-11-18: V20 1896 s < 1932 s / S3 2026-11-20: V20 1896 s < 1932 s |
| M11 | PASS | - |
| M12 | FAIL | A_generacion: S1 2026-11-02: V20 2382 s < 2772 s / S1 2026-11-04: V20 2520 s < 2772 s / S1 2026-11-06: V20 2520 s < 2772 s; F_publicacion: S2 2026-11-09: V20 2382 s < 2772 s / S2 2026-11-11: V20 2520 s < 2772 s / S2 2026-11-13: V20 2520 s < 2772 s; G_continuidad: S3 2026-11-16: V20 2382 s < 2772 s / S3 2026-11-18: V20 2520 s < 2772 s / S3 2026-11-20: V20 2520 s < 2772 s |
| M13 | FAIL | A_generacion: S1 2026-11-02: V20 2190 s < 2772 s / S1 2026-11-03: V20 1812 s < 2772 s / S1 2026-11-05: V20 2310 s < 2772 s / S1 2026-11-06: V20 1812 s < 2772 s; F_publicacion: S2 2026-11-09: V20 2190 s < 2772 s / S2 2026-11-10: V20 1812 s < 2772 s / S2 2026-11-12: V20 2310 s < 2772 s / S2 2026-11-13: V20 1812 s < 2772 s; G_continuidad: S3 2026-11-16: V20 2190 s < 2772 s / S3 2026-11-17: V20 1812 s |
| M14 | FAIL | A_generacion: S1 2026-11-02: V20 2106 s < 3150 s / S1 2026-11-03: V20 1524 s < 3150 s / S1 2026-11-05: V20 1896 s < 3150 s / S1 2026-11-06: V20 1524 s < 3150 s; F_publicacion: S2 2026-11-09: V20 2106 s < 3150 s / S2 2026-11-10: V20 1524 s < 3150 s / S2 2026-11-12: V20 1896 s < 3150 s / S2 2026-11-13: V20 1524 s < 3150 s; G_continuidad: S3 2026-11-16: V20 2106 s < 3150 s / S3 2026-11-17: V20 1524 s |
| M15 | PASS | - |
| M16 | PASS | - |
| M17 | PASS | - |
| M18 | FAIL | A_generacion: S1 2026-11-02: V20 1134 s < 1596 s / S1 2026-11-03: V20 1152 s < 1596 s / S1 2026-11-05: V20 1134 s < 1596 s / S1 2026-11-06: V20 1152 s < 1596 s; F_publicacion: S2 2026-11-09: V20 1134 s < 1596 s / S2 2026-11-10: V20 1152 s < 1596 s / S2 2026-11-12: V20 1134 s < 1596 s / S2 2026-11-13: V20 1152 s < 1596 s; G_continuidad: S3 2026-11-16: V20 1134 s < 1596 s / S3 2026-11-17: V20 1152 s |
| M19 | PASS | - |
| M20 | FAIL | A_generacion: S1 2026-11-03: V20 2391 s < 2394 s / S1 2026-11-06: V20 2391 s < 2394 s; F_publicacion: S2 2026-11-10: V20 2391 s < 2394 s / S2 2026-11-13: V20 2391 s < 2394 s; G_continuidad: S3 2026-11-17: V20 2391 s < 2394 s / S3 2026-11-20: V20 2391 s < 2394 s |
| M21 | FAIL | A_generacion: S1 2026-11-02: V20 2100 s < 2394 s / S1 2026-11-04: V20 1584 s < 2394 s / S1 2026-11-05: V20 1890 s < 2394 s / S1 2026-11-07: V20 1584 s < 2394 s; F_publicacion: S2 2026-11-09: V20 2100 s < 2394 s / S2 2026-11-11: V20 1584 s < 2394 s / S2 2026-11-12: V20 1890 s < 2394 s / S2 2026-11-14: V20 1584 s < 2394 s; G_continuidad: S3 2026-11-16: V20 2100 s < 2394 s / S3 2026-11-18: V20 1584 s |
| M22 | FAIL | A_generacion: S1 2026-11-02: V20 1896 s < 2772 s / S1 2026-11-03: V20 1692 s < 2772 s / S1 2026-11-04: V20 1710 s < 2772 s / S1 2026-11-05: V20 1896 s < 2772 s / S1 2026-11-06: V20 1692 s < 2772 s / S1 2026-11-07: V20 1710 s < 2772 s; F_publicacion: S2 2026-11-09: V20 1896 s < 2772 s / S2 2026-11-10: V20 1692 s < 2772 s / S2 2026-11-11: V20 1710 s < 2772 s / S2 2026-11-12: V20 1896 s < 2772 s / S2 |
| M23 | PASS | - |
| M24 | PASS | - |
| M25 | PASS | - |
| M26 | PASS | - |
| M27 | PASS | - |
| M28 | PASS | - |
| M29 | FAIL | A_generacion: 0 planes vigentes en S1 |
| M30 | FAIL | A_generacion: S1 2026-11-02: V20 1860 s < 1890 s / S1 2026-11-04: V20 1584 s < 1890 s / S1 2026-11-06: V20 1770 s < 1890 s / S1 2026-11-07: V20 1584 s < 1890 s; F_publicacion: S2 2026-11-09: V20 1860 s < 1890 s / S2 2026-11-11: V20 1584 s < 1890 s / S2 2026-11-13: V20 1770 s < 1890 s / S2 2026-11-14: V20 1584 s < 1890 s; G_continuidad: S3 2026-11-16: V20 1860 s < 1890 s / S3 2026-11-18: V20 1584 s |
