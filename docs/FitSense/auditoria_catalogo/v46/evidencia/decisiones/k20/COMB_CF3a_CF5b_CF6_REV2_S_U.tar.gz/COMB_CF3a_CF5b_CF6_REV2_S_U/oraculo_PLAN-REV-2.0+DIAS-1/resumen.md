# Oraculo K20 · COMB_CF3a_CF5b_CF6_REV2_S_U

- Configuracion de calculo activa: MVP-1.8
- Estados: {"PASS": 20}
- Huella normalizada: `f56a933721a4c2d97c716da209936442793a157a89175f0425410685e8fcb99c`

| Usuario | Estado | Fallos |
|---|---|---|
| U01 | PASS | - |
| U02 | PASS | - |
| U03 | PASS | - |
| U04 | PASS | - |
| U05 | PASS | - |
| U06 | PASS | - |
| U07 | PASS | - |
| U08 | PASS | - |
| U09 | PASS | - |
| U10 | PASS | - |
| U11 | PASS | - |
| U12 | PASS | - |
| U13 | PASS | - |
| U14 | PASS | - |
| U15 | PASS | - |
| U16 | PASS | - |
| U17 | PASS | - |
| U18 | PASS | - |
| U19 | PASS | - |
| U20 | PASS | - |
