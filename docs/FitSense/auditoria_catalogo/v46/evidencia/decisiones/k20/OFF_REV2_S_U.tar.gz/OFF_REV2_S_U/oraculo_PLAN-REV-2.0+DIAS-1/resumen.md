# Oraculo K20 · OFF_REV2_S_U

- Configuracion de calculo activa: MVP-1.8
- Estados: {"PASS": 20}
- Huella normalizada: `84dfb6d2160755817cf36c738bef7761ac6ee267a7ca950ba35f6b4f47f9ae6d`

| Usuario | Estado | Fallos |
|---|---|---|
| U01 | PASS | - |
| U02 | PASS | - |
| U03 | PASS | - |
| U04 | PASS | - |
| U05 | PASS | - |
| U06 | PASS | - |
| U07 | PASS | - |
| U08 | PASS | - |
| U09 | PASS | - |
| U10 | PASS | - |
| U11 | PASS | - |
| U12 | PASS | - |
| U13 | PASS | - |
| U14 | PASS | - |
| U15 | PASS | - |
| U16 | PASS | - |
| U17 | PASS | - |
| U18 | PASS | - |
| U19 | PASS | - |
| U20 | PASS | - |
