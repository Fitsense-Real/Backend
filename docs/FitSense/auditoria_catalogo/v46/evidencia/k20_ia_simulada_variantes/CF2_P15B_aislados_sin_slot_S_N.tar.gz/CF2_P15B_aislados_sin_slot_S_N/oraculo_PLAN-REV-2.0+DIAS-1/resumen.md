# Oraculo K20 · CF2_P15B_aislados_sin_slot_S_N

- Configuracion de calculo activa: MVP-1.8
- Estados: {"FAIL": 1, "PASS": 19}
- Huella normalizada: `21dbedfc25ac58f486954ef0de71755ee5be9801d7793ceb20e101832b142eb2`

| Usuario | Estado | Fallos |
|---|---|---|
| N01 | PASS | - |
| N02 | PASS | - |
| N03 | PASS | - |
| N04 | PASS | - |
| N05 | PASS | - |
| N06 | PASS | - |
| N07 | PASS | - |
| N08 | PASS | - |
| N09 | PASS | - |
| N10 | PASS | - |
| N11 | PASS | - |
| N12 | PASS | - |
| N13 | PASS | - |
| N14 | PASS | - |
| N15 | PASS | - |
| N16 | PASS | - |
| N17 | PASS | - |
| N18 | PASS | - |
| N19 | FAIL | A_generacion: 0 planes vigentes en S1 |
| N20 | PASS | - |
