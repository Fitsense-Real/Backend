# Oraculo independiente · evaluacion integral O

- Corridas: MEJR2_A21_R2_G, MEJR2_A21_R2_P
- Perfiles evaluados: 20; sin evaluar: ninguno
- Huella normalizada: `70afb1fc6bd1a05d2bfcb47894b7bb42de3f2693684cd4a5e9fc4b393353ba99`
- Totales (20 x 10 = 200): {'APROBADO': 141, 'NO APLICA': 45, 'REQUIERE REVISION': 14}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 141/141 = 100.0 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 6 | 0 | 0 | 14 |
| A2_personalizacion_restricciones | 20 | 0 | 0 | 0 |
| A3_registro_ejecucion | 19 | 0 | 1 | 0 |
| A4_adherencia | 19 | 0 | 1 | 0 |
| A5_adaptacion_ia | 10 | 0 | 10 | 0 |
| A6_mantenimiento | 19 | 0 | 1 | 0 |
| A7_progresion | 8 | 0 | 12 | 0 |
| A8_reincorporacion | 2 | 0 | 18 | 0 |
| A9_continuidad | 19 | 0 | 1 | 0 |
| A10_seguridad_integridad | 19 | 0 | 1 | 0 |
