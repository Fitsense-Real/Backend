# Oraculo independiente · evaluacion integral O

- Corridas: MEJR2_A24_R3B_G, MEJR2_A24_R3_P
- Perfiles evaluados: 10; sin evaluar: ['O01', 'O02', 'O03', 'O04', 'O07', 'O08', 'O09', 'O10', 'O11', 'O13']
- Huella normalizada: `109ff859275a5a7addf556be47e32fd261c78c85163a4e03d01616d1c302dfb1`
- Totales (20 x 10 = 100): {'REQUIERE REVISION': 8, 'APROBADO': 81, 'NO APLICA': 11}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 81/81 = 100.0 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 2 | 0 | 0 | 8 |
| A2_personalizacion_restricciones | 10 | 0 | 0 | 0 |
| A3_registro_ejecucion | 10 | 0 | 0 | 0 |
| A4_adherencia | 10 | 0 | 0 | 0 |
| A5_adaptacion_ia | 8 | 0 | 2 | 0 |
| A6_mantenimiento | 10 | 0 | 0 | 0 |
| A7_progresion | 7 | 0 | 3 | 0 |
| A8_reincorporacion | 4 | 0 | 6 | 0 |
| A9_continuidad | 10 | 0 | 0 | 0 |
| A10_seguridad_integridad | 10 | 0 | 0 | 0 |
