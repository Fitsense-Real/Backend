# Oraculo independiente · evaluacion integral O

- Corridas: MEJR2_A24_R3_G, MEJR2_A24_R3_P
- Perfiles evaluados: 20; sin evaluar: ninguno
- Huella normalizada: `24001d873c5aaee81c9a205057a027b7f0111321ebfd0ba48a2ca52b44f28ea0`
- Totales (20 x 10 = 200): {'APROBADO': 141, 'NO APLICA': 44, 'REQUIERE REVISION': 15}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 141/141 = 100.0 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 6 | 0 | 0 | 14 |
| A2_personalizacion_restricciones | 20 | 0 | 0 | 0 |
| A3_registro_ejecucion | 19 | 0 | 1 | 0 |
| A4_adherencia | 19 | 0 | 1 | 0 |
| A5_adaptacion_ia | 9 | 0 | 10 | 1 |
| A6_mantenimiento | 19 | 0 | 1 | 0 |
| A7_progresion | 7 | 0 | 13 | 0 |
| A8_reincorporacion | 4 | 0 | 16 | 0 |
| A9_continuidad | 19 | 0 | 1 | 0 |
| A10_seguridad_integridad | 19 | 0 | 1 | 0 |
