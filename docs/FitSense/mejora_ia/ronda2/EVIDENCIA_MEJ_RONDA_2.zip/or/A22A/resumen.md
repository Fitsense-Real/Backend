# Oraculo independiente · evaluacion integral O

- Corridas: MEJR2_A22A_R1_G, MEJR2_A22A_R1_P
- Perfiles evaluados: 20; sin evaluar: ninguno
- Huella normalizada: `ab7b43201fad536c053665345178bdfc669cbe47778dced9baea8b3aa77752e0`
- Totales (20 x 10 = 200): {'APROBADO': 143, 'NO APLICA': 43, 'REQUIERE REVISION': 14}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 143/143 = 100.0 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 6 | 0 | 0 | 14 |
| A2_personalizacion_restricciones | 20 | 0 | 0 | 0 |
| A3_registro_ejecucion | 19 | 0 | 1 | 0 |
| A4_adherencia | 19 | 0 | 1 | 0 |
| A5_adaptacion_ia | 10 | 0 | 10 | 0 |
| A6_mantenimiento | 19 | 0 | 1 | 0 |
| A7_progresion | 8 | 0 | 12 | 0 |
| A8_reincorporacion | 4 | 0 | 16 | 0 |
| A9_continuidad | 19 | 0 | 1 | 0 |
| A10_seguridad_integridad | 19 | 0 | 1 | 0 |
