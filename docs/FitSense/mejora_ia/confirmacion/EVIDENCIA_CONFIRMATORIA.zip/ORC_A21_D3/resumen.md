# Oraculo independiente · evaluacion integral O

- Corridas: CONF_A21_RD3_G, CONF_A21_RD3_P
- Perfiles evaluados: 20; sin evaluar: ninguno
- Huella normalizada: `8e091ff6d9728abc810865cc0a91b05a1fde5f9e59e41f975b3ddd21d0db651c`
- Totales (20 x 10 = 200): {'APROBADO': 142, 'NO APLICA': 44, 'REQUIERE REVISION': 14}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 142/142 = 100.0 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 6 | 0 | 0 | 14 |
| A2_personalizacion_restricciones | 20 | 0 | 0 | 0 |
| A3_registro_ejecucion | 19 | 0 | 1 | 0 |
| A4_adherencia | 19 | 0 | 1 | 0 |
| A5_adaptacion_ia | 10 | 0 | 10 | 0 |
| A6_mantenimiento | 19 | 0 | 1 | 0 |
| A7_progresion | 8 | 0 | 12 | 0 |
| A8_reincorporacion | 3 | 0 | 17 | 0 |
| A9_continuidad | 19 | 0 | 1 | 0 |
| A10_seguridad_integridad | 19 | 0 | 1 | 0 |
