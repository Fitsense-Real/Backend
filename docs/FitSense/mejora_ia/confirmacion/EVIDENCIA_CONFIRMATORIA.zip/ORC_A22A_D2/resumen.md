# Oraculo independiente · evaluacion integral O

- Corridas: CONF_A22A_RD2_G, CONF_A22A_RD2_P
- Perfiles evaluados: 20; sin evaluar: ninguno
- Huella normalizada: `8b9cb6d0d1ee0d8d6f6d70ea31b1ab76f3375e992825bb4d360cb8683c066222`
- Totales (20 x 10 = 200): {'APROBADO': 142, 'NO APLICA': 44, 'REQUIERE REVISION': 14}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 142/142 = 100.0 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 6 | 0 | 0 | 14 |
| A2_personalizacion_restricciones | 20 | 0 | 0 | 0 |
| A3_registro_ejecucion | 19 | 0 | 1 | 0 |
| A4_adherencia | 19 | 0 | 1 | 0 |
| A5_adaptacion_ia | 10 | 0 | 10 | 0 |
| A6_mantenimiento | 19 | 0 | 1 | 0 |
| A7_progresion | 7 | 0 | 13 | 0 |
| A8_reincorporacion | 4 | 0 | 16 | 0 |
| A9_continuidad | 19 | 0 | 1 | 0 |
| A10_seguridad_integridad | 19 | 0 | 1 | 0 |
