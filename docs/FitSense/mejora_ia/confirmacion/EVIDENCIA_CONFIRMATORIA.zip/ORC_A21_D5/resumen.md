# Oraculo independiente · evaluacion integral O

- Corridas: CONF_A21_RD5_G, CONF_A21_RD5_P
- Perfiles evaluados: 20; sin evaluar: ninguno
- Huella normalizada: `6a9e61cba0c5ee04bf9cc1f9914a2a687c3d24c53e3ec5bbc6c38392cbf45899`
- Totales (20 x 10 = 200): {'APROBADO': 141, 'NO APLICA': 44, 'REQUIERE REVISION': 15}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 141/141 = 100.0 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 6 | 0 | 0 | 14 |
| A2_personalizacion_restricciones | 20 | 0 | 0 | 0 |
| A3_registro_ejecucion | 19 | 0 | 1 | 0 |
| A4_adherencia | 19 | 0 | 1 | 0 |
| A5_adaptacion_ia | 9 | 0 | 10 | 1 |
| A6_mantenimiento | 19 | 0 | 1 | 0 |
| A7_progresion | 8 | 0 | 12 | 0 |
| A8_reincorporacion | 3 | 0 | 17 | 0 |
| A9_continuidad | 19 | 0 | 1 | 0 |
| A10_seguridad_integridad | 19 | 0 | 1 | 0 |
