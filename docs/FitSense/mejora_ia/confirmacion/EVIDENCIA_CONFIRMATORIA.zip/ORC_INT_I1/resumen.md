# Oraculo independiente · evaluacion integral O

- Corridas: CONF_INT_RI1_G, CONF_INT_RI1_P
- Perfiles evaluados: 20; sin evaluar: ninguno
- Huella normalizada: `a0e295eae7279f6c69b57865ed294679ad9179f7229176d93ec78f22331a7103`
- Totales (20 x 10 = 200): {'APROBADO': 148, 'NO APLICA': 44, 'REQUIERE REVISION': 8}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 148/148 = 100.0 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 12 | 0 | 0 | 8 |
| A2_personalizacion_restricciones | 20 | 0 | 0 | 0 |
| A3_registro_ejecucion | 19 | 0 | 1 | 0 |
| A4_adherencia | 19 | 0 | 1 | 0 |
| A5_adaptacion_ia | 10 | 0 | 10 | 0 |
| A6_mantenimiento | 19 | 0 | 1 | 0 |
| A7_progresion | 8 | 0 | 12 | 0 |
| A8_reincorporacion | 3 | 0 | 17 | 0 |
| A9_continuidad | 19 | 0 | 1 | 0 |
| A10_seguridad_integridad | 19 | 0 | 1 | 0 |
