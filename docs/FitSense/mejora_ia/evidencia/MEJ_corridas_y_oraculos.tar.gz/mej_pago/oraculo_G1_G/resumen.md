# Oraculo independiente · evaluacion integral O

- Corridas: MEJ_G1_G
- Perfiles evaluados: 14; sin evaluar: ['O15', 'O16', 'O17', 'O18', 'O19', 'O20']
- Huella normalizada: `5e65b5fde80be9649534bf7f11261108b6ed73b141ff8da2e1ece65e6dc2003f`
- Totales (20 x 10 = 140): {'APROBADO': 89, 'NO APLICA': 40, 'REQUIERE REVISION': 11}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 89/89 = 100.0 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 4 | 0 | 0 | 10 |
| A2_personalizacion_restricciones | 14 | 0 | 0 | 0 |
| A3_registro_ejecucion | 13 | 0 | 1 | 0 |
| A4_adherencia | 13 | 0 | 1 | 0 |
| A5_adaptacion_ia | 5 | 0 | 8 | 1 |
| A6_mantenimiento | 13 | 0 | 1 | 0 |
| A7_progresion | 0 | 0 | 14 | 0 |
| A8_reincorporacion | 1 | 0 | 13 | 0 |
| A9_continuidad | 13 | 0 | 1 | 0 |
| A10_seguridad_integridad | 13 | 0 | 1 | 0 |
