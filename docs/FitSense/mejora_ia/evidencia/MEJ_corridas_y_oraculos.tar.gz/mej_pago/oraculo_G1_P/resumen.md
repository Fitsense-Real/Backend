# Oraculo independiente · evaluacion integral O

- Corridas: MEJ_G1_P
- Perfiles evaluados: 6; sin evaluar: ['O01', 'O02', 'O03', 'O04', 'O05', 'O06', 'O07', 'O08', 'O09', 'O10', 'O11', 'O12', 'O13', 'O14']
- Huella normalizada: `42a4da13d8c87a0deb4bc979e38d5e1da2cc4b1a6931b5ac6ad2b624849ee3a3`
- Totales (20 x 10 = 60): {'APROBADO': 52, 'NO APLICA': 7, 'REQUIERE REVISION': 1}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 52/52 = 100.0 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 5 | 0 | 0 | 1 |
| A2_personalizacion_restricciones | 6 | 0 | 0 | 0 |
| A3_registro_ejecucion | 6 | 0 | 0 | 0 |
| A4_adherencia | 6 | 0 | 0 | 0 |
| A5_adaptacion_ia | 4 | 0 | 2 | 0 |
| A6_mantenimiento | 6 | 0 | 0 | 0 |
| A7_progresion | 6 | 0 | 0 | 0 |
| A8_reincorporacion | 1 | 0 | 5 | 0 |
| A9_continuidad | 6 | 0 | 0 | 0 |
| A10_seguridad_integridad | 6 | 0 | 0 | 0 |
