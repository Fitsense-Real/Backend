# Oraculo independiente · evaluacion integral O

- Corridas: MEJ_G1R_G
- Perfiles evaluados: 1; sin evaluar: ['O01', 'O02', 'O04', 'O05', 'O06', 'O07', 'O08', 'O09', 'O10', 'O11', 'O12', 'O13', 'O14', 'O15', 'O16', 'O17', 'O18', 'O19', 'O20']
- Huella normalizada: `9094bb3b3c7447f6863eb11624b80fb81107a2f3f72de2f7abd5deeff48bcbda`
- Totales (20 x 10 = 10): {'REQUIERE REVISION': 1, 'APROBADO': 8, 'NO APLICA': 1}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 8/8 = 100.0 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 0 | 0 | 0 | 1 |
| A2_personalizacion_restricciones | 1 | 0 | 0 | 0 |
| A3_registro_ejecucion | 1 | 0 | 0 | 0 |
| A4_adherencia | 1 | 0 | 0 | 0 |
| A5_adaptacion_ia | 1 | 0 | 0 | 0 |
| A6_mantenimiento | 1 | 0 | 0 | 0 |
| A7_progresion | 1 | 0 | 0 | 0 |
| A8_reincorporacion | 0 | 0 | 1 | 0 |
| A9_continuidad | 1 | 0 | 0 | 0 |
| A10_seguridad_integridad | 1 | 0 | 0 | 0 |
