# Oraculo independiente · evaluacion integral O

- Corridas: MEJ_CC_P
- Perfiles evaluados: 2; sin evaluar: ['O01', 'O02', 'O03', 'O04', 'O05', 'O06', 'O07', 'O08', 'O09', 'O10', 'O11', 'O12', 'O13', 'O14', 'O15', 'O16', 'O17', 'O18']
- Huella normalizada: `dcd85b5f16c91792440d7c16252fbc02a27535aed4f11ee8007a24ae8295f6e5`
- Totales (20 x 10 = 20): {'REQUIERE REVISION': 1, 'APROBADO': 18, 'NO APLICA': 1}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 18/18 = 100.0 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 1 | 0 | 0 | 1 |
| A2_personalizacion_restricciones | 2 | 0 | 0 | 0 |
| A3_registro_ejecucion | 2 | 0 | 0 | 0 |
| A4_adherencia | 2 | 0 | 0 | 0 |
| A5_adaptacion_ia | 2 | 0 | 0 | 0 |
| A6_mantenimiento | 2 | 0 | 0 | 0 |
| A7_progresion | 2 | 0 | 0 | 0 |
| A8_reincorporacion | 1 | 0 | 1 | 0 |
| A9_continuidad | 2 | 0 | 0 | 0 |
| A10_seguridad_integridad | 2 | 0 | 0 | 0 |
