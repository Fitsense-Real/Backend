# Oraculo independiente · evaluacion integral O

- Corridas: MEJ_C_G, MEJ_C_P
- Perfiles evaluados: 20; sin evaluar: ninguno
- Huella normalizada: `c1c5cd735ba5eb810ac1ff83e6c9be590544cee86737d087ecd4b8bfbc94d1ad`
- Totales (20 x 10 = 200): {'APROBADO': 145, 'NO APLICA': 45, 'REQUIERE REVISION': 9, 'FALLO': 1}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 145/146 = 99.3 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 10 | 1 | 0 | 9 |
| A2_personalizacion_restricciones | 20 | 0 | 0 | 0 |
| A3_registro_ejecucion | 19 | 0 | 1 | 0 |
| A4_adherencia | 19 | 0 | 1 | 0 |
| A5_adaptacion_ia | 10 | 0 | 10 | 0 |
| A6_mantenimiento | 19 | 0 | 1 | 0 |
| A7_progresion | 8 | 0 | 12 | 0 |
| A8_reincorporacion | 2 | 0 | 18 | 0 |
| A9_continuidad | 19 | 0 | 1 | 0 |
| A10_seguridad_integridad | 19 | 0 | 1 | 0 |
