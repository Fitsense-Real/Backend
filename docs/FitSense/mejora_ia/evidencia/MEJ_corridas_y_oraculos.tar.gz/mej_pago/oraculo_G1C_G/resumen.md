# Oraculo independiente · evaluacion integral O

- Corridas: MEJ_G1C_G
- Perfiles evaluados: 10; sin evaluar: ['O01', 'O02', 'O03', 'O11', 'O15', 'O16', 'O17', 'O18', 'O19', 'O20']
- Huella normalizada: `6028643dac93d5eba2abd594000cd7846103a0ced30c07aa1b490bcc70e9f45d`
- Totales (20 x 10 = 100): {'REQUIERE REVISION': 7, 'APROBADO': 68, 'FALLO': 2, 'NO APLICA': 23}
- Aprobacion tecnica sobre aplicables (APROBADO / (APROBADO + FALLO)): 68/70 = 97.1 %

| Aspecto | APROBADO | FALLO | NO APLICA | REQUIERE REVISION |
|---|---|---|---|---|
| A1_generacion | 3 | 1 | 0 | 6 |
| A2_personalizacion_restricciones | 10 | 0 | 0 | 0 |
| A3_registro_ejecucion | 10 | 0 | 0 | 0 |
| A4_adherencia | 10 | 0 | 0 | 0 |
| A5_adaptacion_ia | 3 | 1 | 5 | 1 |
| A6_mantenimiento | 10 | 0 | 0 | 0 |
| A7_progresion | 1 | 0 | 9 | 0 |
| A8_reincorporacion | 1 | 0 | 9 | 0 |
| A9_continuidad | 10 | 0 | 0 | 0 |
| A10_seguridad_integridad | 10 | 0 | 0 | 0 |
